using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catalogo
{
    class Venta
    {
        private Producto producto;
        private int noPiezas;
        private double subTotal;


        public Venta(Producto producto, int noPiezas)
        {
            this.producto = producto;
            this.noPiezas = noPiezas;
            subTotal =producto.Descripcion.Precio * noPiezas;
        }

        public double SubTotal
        { 
            get { 
                return subTotal; 
                
            } 
        }

        public int Piezas{
            get { return noPiezas; }

            set { 
                noPiezas = value;
                subTotal = producto.Descripcion.Precio * noPiezas;
            }
            
        }

        public Producto Producto
        {
            get { return producto; } 
        }

        public override string ToString()
        {
            string cadena= producto.Id+","+noPiezas;
            return cadena;
        }

    }
}
