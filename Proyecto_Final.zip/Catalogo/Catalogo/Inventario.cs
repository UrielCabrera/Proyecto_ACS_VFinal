using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Catalogo
{
    class Inventario
    {
        private Producto[] productos;      
        private string[] productosToString;
        private int totalProductos;
        public Inventario(){
            productos = new Producto[18];
            productosToString= new string[18];
            totalProductos = 0;            
        }

        //Agrega un producto al array de productos y su cadena al array de productosToString. Ademas de incrementar el totalProductos
        public void AgregarProducto(Producto articulo){
            productos[totalProductos] = articulo;
            productosToString[totalProductos] = articulo.ToString();
            totalProductos = totalProductos + 1;
        }

        //Modifica la existencia de un producto y manda a reescribir el RegistroTemporal
        internal void ModificarExistenciaProd(int indice,int piezas,int opcion) {
            int num = productos[indice].Existencias.PiezasInventario;
            if (opcion == 1) {
                productos[indice].Existencias.PiezasInventario = num - piezas;
            }
            if (opcion == 2)
            {
                productos[indice].Existencias.PiezasInventario = num + piezas;
            }
            ReescribirInventario();
        }

        //Reescribe el archivo RegistroTemporal con lo que hay actualmente en productosToString
        private void ReescribirInventario()
        {
            using (StreamWriter escribir = new StreamWriter(@"RegistroTemporal.txt"))
            {
                foreach (string cad in productosToString)
                {
                    escribir.WriteLine(cad);
                }
            }
        }
        public Producto[] Productos
        {
            get
            {
                return productos;
            }
        }
        public string[] ProductosToString
        {
            get
            {
                return productosToString;
            }
        }
        public Producto GetProducto(int indice) { 
            return productos[indice]; 
        }
        public int TotalProductos {
            get { return totalProductos; }
        }


    
    }
}
