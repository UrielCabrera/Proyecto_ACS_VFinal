using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Catalogo
{
    public class ControlVentas
    {
        private Carrito carrito;
        ControlInventario ctrlInventarioCarrito = new ControlInventario();
        private string leerVentas;
        private string[] filas;

        public ControlVentas() {
            carrito = new Carrito();
            leerVentas = File.ReadAllText("Venta.txt");
            ctrlInventarioCarrito.CargarInventario(1); //Carga el archivo Registro
            if (leerVentas.Length!=0) { //Si ventas no esta vacio
                filas = leerVentas.Split(new string[] { System.Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            }            
        }

        //Carga las ventas al carrito
        internal void CargarVentasDeArchivo()
        {
            if (leerVentas.Length>0) { //Si ventas no esta vacio

                    if (carrito.NumeroArticulos == 0)
                    {  //Si el carrito no tiene ninguna venta
                        CrearVenta();

                    }

                
            }
             //termina else      
           
        }

        //Lee y extrae del archivo.Para crear las ventas y añadirlas al carrito
        private void CrearVenta(){ 
            int idImagen;
            int numPiezas;
            string[] columnas;
            foreach (string linea in filas)
            {
                columnas = linea.Split(',');
                idImagen = Convert.ToInt32(columnas[0]);
                numPiezas = Convert.ToInt32(columnas[1]);
                carrito.AgregarVenta(new Venta(ctrlInventarioCarrito.Inventario.GetProducto(idImagen), numPiezas));
            }
        }

        internal void LimpiarCarrito()
        {
            using (StreamWriter escribir = new StreamWriter(@"Venta.txt"))
            {
                for (int x = 0; x <carrito.NumeroArticulos; x++)
                {
                    escribir.WriteLine("");
                }
            }
        }

        internal Carrito Carrito {
            get { return carrito; }
        }




    }
}
