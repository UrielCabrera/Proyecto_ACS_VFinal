using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Catalogo
{
    class Carrito
    {
        private ArrayList ventas;
        private string[] ventasString;        
        private int numeroArticulos;
        private double total;

        public Carrito()
        {
            ventas = new ArrayList();
            total = 0;
            numeroArticulos = 0;
        }

        //Agrega la venta y revisa las coincidencias de esa venta
        internal void AgregarVenta(Venta venta){
            if (ventas.Count == 0)
            {
                Agregar(venta);
            }
            else
            {
                    if (coincidencias(venta) == false)
                    {
                        Agregar(venta);
                    }              
            }
        }

        //Agrega la venta,modifica el total y el numero de articulos
        private void Agregar(Venta venta) {
            ventas.Add(venta);
            total = total + venta.SubTotal;
            numeroArticulos = numeroArticulos + 1;
        }

        //Si hay coincidencias modifica la venta,el total y retorna true. En caso contrario retorna false
        private bool coincidencias(Venta ven1){
            for (int x = 0; x < ventas.Count; x++){
                if (((Venta)ventas[x]).Producto.Id == ven1.Producto.Id){
                    ((Venta)ventas[x]).Piezas = ((Venta)ventas[x]).Piezas + ven1.Piezas;
                    total = total + ven1.SubTotal;
                    return true;
                }
            }
            return false;
        }

        /*Elimina una venta de la lista de ventas*/
        internal void EliminarVenta(int indice,Inventario inventa) 
        {
            Venta venTemporal = ((Venta)ventas[indice]);
            total = total - venTemporal.SubTotal;
            numeroArticulos = numeroArticulos - 1;
            inventa.ModificarExistenciaProd(venTemporal.Producto.Id,venTemporal.Piezas,2);
            ventas.RemoveAt(indice);
            ModificarVentas();
        }
        private void ModificarVentas() {
            VentasToString();
            using (StreamWriter escribir = new StreamWriter(@"Venta.txt")){
                foreach (string cad in ventasString){
                    escribir.WriteLine(cad);
                }
            }
        }
        private void VentasToString(){
            ventasString = new string[numeroArticulos];
            for (int i = 0; i < numeroArticulos; i++){
                ventasString[i] = ((Venta)Ventas[i]).ToString();
            }
        }
        internal Venta getVenta(int indice)
        {
            return (Venta)ventas[indice]; 
        }      
        public Venta[] Ventas{
            get
            {
                Venta[] listaVentas = new Venta[ventas.Count];
                for (int i = 0; i < ventas.Count; i++)
                {
                    listaVentas[i] = (Venta)ventas[i];
                }
                return listaVentas;
            }
        }
        public double Total
        {
            get { return total; }
        }
        public int NumeroArticulos
        {
            get { return numeroArticulos; }
        }
    }
}
